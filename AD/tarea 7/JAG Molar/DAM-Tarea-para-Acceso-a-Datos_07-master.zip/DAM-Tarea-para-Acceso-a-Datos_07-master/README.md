# DAM-Tarea-para-Acceso-a-Datos_07
Realización de tarea para el tema 7 de Acceso a Datos
