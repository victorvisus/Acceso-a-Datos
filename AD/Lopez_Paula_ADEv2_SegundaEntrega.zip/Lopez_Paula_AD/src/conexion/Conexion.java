package conexion;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Paula
 */
public class Conexion {
    
    private static Connection conexion;

    /**
     * Método para crear la conexión
     * 
     * @return
     */
    public static Connection getConexion() {
        if (conexion == null) {
            try {
                Class.forName("oracle.jdbc.OracleDriver");
                conexion = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "c##AD_EX2", "AD_EX2");
            } catch (ClassNotFoundException | SQLException ex) {
                Logger.getLogger(Conexion.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return conexion;
    }
    
}
