package clases;

/**
 *
 * @author Paula
 */
public class Inmueble {
    
    int planta;
    int metros2;
    int numHabitaciones;
    int numBannios;
    String promotor;

    public Inmueble() {
    }

    public Inmueble(int planta, int metros2, int numHabitaciones, int numBannios, String promotor) {
        this.planta = planta;
        this.metros2 = metros2;
        this.numHabitaciones = numHabitaciones;
        this.numBannios = numBannios;
        this.promotor = promotor;
    }

    public int getPlanta() {
        return planta;
    }

    public void setPlanta(int planta) {
        this.planta = planta;
    }

    public int getMetros2() {
        return metros2;
    }

    public void setMetros2(int metros2) {
        this.metros2 = metros2;
    }

    public int getNumHabitaciones() {
        return numHabitaciones;
    }

    public void setNumHabitaciones(int numHabitaciones) {
        this.numHabitaciones = numHabitaciones;
    }

    public int getNumBannios() {
        return numBannios;
    }

    public void setNumBannios(int numBannios) {
        this.numBannios = numBannios;
    }

    public String getPromotor() {
        return promotor;
    }

    public void setPromotor(String promotor) {
        this.promotor = promotor;
    }
    
    
    
}
