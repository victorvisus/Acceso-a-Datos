package clases;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;

/**
 *
 * @author Paula
 */
public class Controladores {

    Local local = new Local();
    Cliente cliente = new Cliente();

    /**
     * Método para crear los tipos
     *
     * @param conexion
     */
    public static void crearTipos(Connection conexion) {

        try (Statement stmt = conexion.createStatement()) {
            stmt.executeUpdate("CREATE OR REPLACE TYPE inmueble_t AS OBJECT (planta NUMBER, metros2 NUMBER, numHabitaciones NUMBER, numBannios NUMBER, promotor VARCHAR(25))");
            stmt.executeUpdate("CREATE OR REPLACE TYPE direccion_t AS OBJECT (calle VARCHAR2(40), ciudad VARCHAR2(25), codPostal VARCHAR2(5))");
            stmt.executeUpdate("CREATE OR REPLACE TYPE cuentaBancaria_t AS OBJECT (codPais VARCHAR2(2), digControl1 NUMBER, entidad NUMBER, oficina NUMBER, digControl2 NUMBER, numCuenta NUMBER)");

            JOptionPane.showMessageDialog(null, "Tipos Creados");

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage());
        }
    }

    /**
     * Método para crear las tablas
     *
     * @param conexion
     */
    public static void crearTablas(Connection conexion) {

        try (Statement stmt = conexion.createStatement()) {
            stmt.executeUpdate("CREATE TABLE local_tb (identificador VARCHAR2(9) PRIMARY KEY, descripcion inmueble_t, direccionLocal direccion_t, importeAlquiler FLOAT)");
            stmt.executeUpdate("CREATE TABLE cliente_tb (dni VARCHAR2(9) PRIMARY KEY, nombre VARCHAR2(25), apellidos VARCHAR2(50), direccionCliente direccion_t, email VARCHAR2(50), cuentaBancaria cuentaBancaria_t)");
            stmt.executeUpdate("CREATE TABLE alquiler_tb (idAlquiler VARCHAR2(9) PRIMARY KEY, idLocal VARCHAR2(9), dniCliente VARCHAR2(9), fechaInicio DATE, fechaFin DATE, alquilado CHAR(1))");

            JOptionPane.showMessageDialog(null, "Tablas Creadas");

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage());
        }
    }

    /**
     * Método para borrar las estructuras creadas
     *
     * @param conexion
     */
    public static void eliminarEstructuras(Connection conexion) {

        try (Statement stmt = conexion.createStatement()) {

            stmt.execute("DROP TABLE alquiler_tb");
            stmt.execute("DROP TABLE local_tb");
            stmt.execute("DROP TABLE cliente_tb");
            stmt.execute("DROP TYPE inmueble_t");
            stmt.execute("DROP TYPE direccion_t");
            stmt.execute("DROP TYPE cuentaBancaria_t");

            JOptionPane.showMessageDialog(null, "Estructura Eliminada");

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage());
        }

    }


}
