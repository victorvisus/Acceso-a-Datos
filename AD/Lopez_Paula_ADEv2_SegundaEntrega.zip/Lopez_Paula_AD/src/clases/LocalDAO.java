package clases;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author Paula
 */
public class LocalDAO {

    /**
     * Método para insertar locales
     *
     * @param conexion
     * @param local
     */
    public static void insertarLocal(Connection conexion, Local local) {

        try (PreparedStatement pstm = conexion.prepareStatement("INSERT INTO local_tb VALUES (?, inmueble_t(?, ?, ?, ?, ?), direccion_t(?, ?, ?), ?)")) {

            //Asignamos los valores a los parametros
            pstm.setString(1, local.getIdentificador());
            pstm.setInt(2, local.getDescripcion().getPlanta());
            pstm.setInt(3, local.getDescripcion().getMetros2());
            pstm.setInt(4, local.getDescripcion().getNumHabitaciones());
            pstm.setInt(5, local.getDescripcion().getNumBannios());
            pstm.setString(6, local.getDescripcion().getPromotor());
            pstm.setString(7, local.getDireccionLocal_t().getCalle());
            pstm.setString(8, local.getDireccionLocal_t().getCiudad());
            pstm.setString(9, local.getDireccionLocal_t().getCodPostal());
            pstm.setFloat(10, local.getImporteAlquiler());

            pstm.executeUpdate();

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage());
        }
    }

    /**
     * Método para modificar locales
     *
     * @param conexion
     * @param local
     */
    public static void modificarLocal(Connection conexion, Local local) {

        try (PreparedStatement pstm = conexion.prepareStatement("UPDATE local_tb lt SET descripcion = inmueble_t(?, ?, ?, ?, ?), direccionLocal = direccion_t(?, ?, ?), importeAlquiler = ? WHERE identificador = ?")) {

            //Asignamos los valores a los parametros           
            pstm.setInt(1, local.getDescripcion().getPlanta());
            pstm.setInt(2, local.getDescripcion().getMetros2());
            pstm.setInt(3, local.getDescripcion().getNumHabitaciones());
            pstm.setInt(4, local.getDescripcion().getNumBannios());
            pstm.setString(5, local.getDescripcion().getPromotor());
            pstm.setString(6, local.getDireccionLocal_t().getCalle());
            pstm.setString(7, local.getDireccionLocal_t().getCiudad());
            pstm.setString(8, local.getDireccionLocal_t().getCodPostal());
            pstm.setFloat(9, local.getImporteAlquiler());
            pstm.setString(10, local.getIdentificador());

            pstm.executeUpdate();

            JOptionPane.showMessageDialog(null, "Local modificado correctamente");

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage());
        }
    }

    /**
     * Método para obtener locales
     *
     * @param conexion
     * @param identificador
     *
     */
    public static Local obtenerLocal(Connection conexion, String identificador) {

        try (PreparedStatement pstm = conexion.prepareStatement("SELECT lt.identificador, lt.descripcion.planta, lt.descripcion.metros2, lt.descripcion.numHabitaciones, lt.descripcion.numBannios, lt.descripcion.promotor, lt.direccionLocal.calle, lt.direccionLocal.ciudad, lt.direccionLocal.codPostal, lt.importeAlquiler FROM local_tb lt WHERE identificador = ?")) {
            
            pstm.setString(1, identificador);

            try (ResultSet rs = pstm.executeQuery()) {
                
                if (rs.next()) {
                    String id = rs.getString("identificador");
                    int planta = rs.getInt("descripcion.planta");
                    int metros2 = rs.getInt("descripcion.metros2");
                    int numHabitaciones = rs.getInt("descripcion.numHabitaciones");
                    int numBannios = rs.getInt("descripcion.numBannios");
                    String promotor = rs.getString("descripcion.promotor");
                    String calle = rs.getString("direccionLocal.calle");
                    String ciudad = rs.getString("direccionLocal.ciudad");
                    String codPostal = rs.getString("direccionLocal.codPostal");
                    float importeAlquiler = rs.getFloat("importeAlquiler");

                    Local local = new Local(id, new Inmueble(planta, metros2, numHabitaciones, numBannios, promotor), new Direccion(calle, ciudad, codPostal), importeAlquiler);
                    return local;
                    
                } else {
                    return null;
                }
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage());
            
            return null;
        }
    }

    /**
     * Método para eliminar locales
     *
     * @param conexion
     * @param identificador
     *
     */
    public static void eliminarLocal(Connection conexion, String identificador) {

        try (PreparedStatement pstm = conexion.prepareStatement("DELETE FROM local_tb WHERE identificador = ?")) {
            pstm.setString(1, identificador);
            pstm.executeUpdate();

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage());
        }
    }

}
