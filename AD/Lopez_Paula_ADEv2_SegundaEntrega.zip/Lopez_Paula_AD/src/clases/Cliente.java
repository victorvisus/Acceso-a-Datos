package clases;

/**
 *
 * @author Paula
 */
public class Cliente {
    
    String dni;
    String nombre;
    String apellidos;
    Direccion direccionCliente_t;
    String email;
    CuentaBancaria cuentaBancaria_t;

    public Cliente() {
    }

    public Cliente(String dni, String nombre, String apellidos, Direccion direccionCliente_t, String email, CuentaBancaria cuentaBancaria_t) {
        this.dni = dni;
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.direccionCliente_t = direccionCliente_t;
        this.email = email;
        this.cuentaBancaria_t = cuentaBancaria_t;
    }

    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public Direccion getDireccionCliente_t() {
        return direccionCliente_t;
    }

    public void setDireccionCliente_t(Direccion direccionCliente_t) {
        this.direccionCliente_t = direccionCliente_t;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public CuentaBancaria getCuentaBancaria_t() {
        return cuentaBancaria_t;
    }

    public void setCuentaBancaria_t(CuentaBancaria cuentaBancaria_t) {
        this.cuentaBancaria_t = cuentaBancaria_t;
    }
    
    
    
}

  
