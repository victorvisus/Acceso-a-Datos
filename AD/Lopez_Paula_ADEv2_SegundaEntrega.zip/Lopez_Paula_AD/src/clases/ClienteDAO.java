package clases;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author Paula
 */
public class ClienteDAO {

    /**
     * Método para insertar locales
     *
     * @param conexion
     * @param cliente
     */
    public static void insertarCliente(Connection conexion, Cliente cliente) {

        try (PreparedStatement pstm = conexion.prepareStatement("INSERT INTO cliente_tb VALUES (?, ?, ?, direccion_t(?, ?, ?), ?, cuentaBancaria_t(?, ?, ?, ?, ?, ?))")) {

            //Asignamos los valores a los parámetros
            pstm.setString(1, cliente.getDni());
            pstm.setString(2, cliente.getNombre());
            pstm.setString(3, cliente.getApellidos());
            pstm.setString(4, cliente.getDireccionCliente_t().getCalle());
            pstm.setString(5, cliente.getDireccionCliente_t().getCiudad());
            pstm.setString(6, cliente.getDireccionCliente_t().getCodPostal());
            pstm.setString(7, cliente.getEmail());
            pstm.setString(8, cliente.getCuentaBancaria_t().getCodPais());
            pstm.setInt(9, cliente.getCuentaBancaria_t().getDigControl1());
            pstm.setInt(10, cliente.getCuentaBancaria_t().getEntidad());
            pstm.setInt(11, cliente.getCuentaBancaria_t().getOficina());
            pstm.setInt(12, cliente.getCuentaBancaria_t().getDigControl2());
            pstm.setInt(13, cliente.getCuentaBancaria_t().getNumCuenta());

            pstm.executeUpdate();

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage());
        }
    }

    /**
     * Método para eliminar clientes
     *
     * @param conexion
     * @param nombreCliente
     */
    public static void eliminarCliente(Connection conexion, String nombreCliente) {

        try (PreparedStatement pstm = conexion.prepareStatement("DELETE FROM cliente_tb WHERE nombre = ?")) {
            pstm.setString(1, nombreCliente);
            pstm.executeUpdate();

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage());
        }
    }

    /**
     * Método para obtener los últimos alquieres de un cliente
     *
     * @param conexion
     * @param dniCliente
     */
    public static void obtenerUltimosAlquileres(Connection conexion, String dniCliente) {
        
        try (PreparedStatement pstm = conexion.prepareStatement("SELECT tb.*, ct.nombre, ct.apellidos FROM alquiler_tb tb JOIN cliente_tb ct ON ct.dni= tb.dnicliente WHERE tb.dnicliente = ? ORDER BY tb.fechainicio DESC")) {

            pstm.setString(1, dniCliente);

            try (ResultSet rs = pstm.executeQuery()) {

                String mensaje = "";

                if (rs.next()) {
                    mensaje = "El último local alquilado por " + rs.getString("nombre") + " tiene identificador " + rs.getString("idLocal") + " y se alquiló el día " + rs.getString("fechaInicio");

                    if (rs.next()) {
                        mensaje += "\n" + "El penúltimo local alquilado por " + rs.getString("nombre") + " tiene identificador " + rs.getString("idLocal") + " y se alquiló el día " + rs.getString("fechaInicio");
                    }

                    JOptionPane.showMessageDialog(null, mensaje);

                } else {
                    JOptionPane.showMessageDialog(null, "No se han encontrado alquileres");
                }

            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, ex.getMessage());
            }

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage());
        }
    }

}
