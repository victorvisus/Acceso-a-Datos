package clases;

import java.sql.Date;

/**
 *
 * @author Paula
 */
public class Alquiler {
    
    private String idAlquiler;
    private Local local;
    private Cliente cliente;
    private Date fechaInicio;
    private Date fechaFin;
    private boolean alquilado;

    public Alquiler() {
    }

    public Alquiler(String idAlquiler, Local local, Cliente cliente, Date fechaInicio, Date fechaFin, boolean alquilado) {
        this.idAlquiler = idAlquiler;
        this.local = local;
        this.cliente = cliente;
        this.fechaInicio = fechaInicio;
        this.fechaFin = fechaFin;
        this.alquilado = alquilado;
    }

    public String getIdAlquiler() {
        return idAlquiler;
    }

    public void setIdAlquiler(String idAlquiler) {
        this.idAlquiler = idAlquiler;
    }

    public Local getLocal() {
        return local;
    }

    public void setLocal(Local local) {
        this.local = local;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public Date getFechaInicio() {
        return fechaInicio;
    }

    public void setFechaInicio(Date fechaInicio) {
        this.fechaInicio = fechaInicio;
    }

    public Date getFechaFin() {
        return fechaFin;
    }

    public void setFechaFin(Date fechaFin) {
        this.fechaFin = fechaFin;
    }

    public boolean isAlquilado() {
        return alquilado;
    }

    public void setAlquilado(boolean alquilado) {
        this.alquilado = alquilado;
    }
    
    
    
}
