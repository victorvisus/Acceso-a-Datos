package clases;

/**
 *
 * @author Paula
 */
public class CuentaBancaria {
    
    String codPais;
    int digControl1;
    int entidad;
    int oficina;
    int digControl2;
    int numCuenta;

    public CuentaBancaria() {
    }

    public CuentaBancaria(String codPais, int digControl1, int entidad, int oficina, int digControl2, int numCuenta) {
        this.codPais = codPais;
        this.digControl1 = digControl1;
        this.entidad = entidad;
        this.oficina = oficina;
        this.digControl2 = digControl2;
        this.numCuenta = numCuenta;
    }

    public String getCodPais() {
        return codPais;
    }

    public void setCodPais(String codPais) {
        this.codPais = codPais;
    }

    public int getDigControl1() {
        return digControl1;
    }

    public void setDigControl1(int digControl1) {
        this.digControl1 = digControl1;
    }

    public int getEntidad() {
        return entidad;
    }

    public void setEntidad(int entidad) {
        this.entidad = entidad;
    }

    public int getOficina() {
        return oficina;
    }

    public void setOficina(int oficina) {
        this.oficina = oficina;
    }

    public int getDigControl2() {
        return digControl2;
    }

    public void setDigControl2(int digControl2) {
        this.digControl2 = digControl2;
    }

    public int getNumCuenta() {
        return numCuenta;
    }

    public void setNumCuenta(int numCuenta) {
        this.numCuenta = numCuenta;
    }
    
    
    
}
