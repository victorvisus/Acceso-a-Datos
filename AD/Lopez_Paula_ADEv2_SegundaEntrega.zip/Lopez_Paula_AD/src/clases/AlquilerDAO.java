package clases;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author Paula
 */
public class AlquilerDAO {

    /**
     * Método para insertar alquileres
     *
     * @param conexion
     * @param alquiler
     */
    public static void insertarAlquiler(Connection conexion, Alquiler alquiler) {

        try (PreparedStatement pstm = conexion.prepareStatement("INSERT INTO alquiler_tb VALUES (?, ?, ?, ?, ?, ?)")) {

            //Asignamos los valores a los parámetros
            pstm.setString(1, alquiler.getIdAlquiler());
            pstm.setString(2, alquiler.getLocal().getIdentificador());
            pstm.setString(3, alquiler.getCliente().getDni());
            pstm.setDate(4, alquiler.getFechaInicio());
            pstm.setDate(5, alquiler.getFechaFin());
            pstm.setBoolean(6, alquiler.isAlquilado());

            pstm.executeUpdate();

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage());
        }
    }

    
}
