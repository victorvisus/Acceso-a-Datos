package clases;

/**
 *
 * @author Paula
 */
public class Local {
    
    String identificador;
    Inmueble descripcion;
    Direccion direccionLocal_t;
    float importeAlquiler;

    public Local() {
    }

    public Local(String identificador, Inmueble descripcion, Direccion direccionLocal_t, float importeAlquiler) {
        this.identificador = identificador;
        this.descripcion = descripcion;
        this.direccionLocal_t = direccionLocal_t;
        this.importeAlquiler = importeAlquiler;
    }

    public String getIdentificador() {
        return identificador;
    }

    public void setIdentificador(String identificador) {
        this.identificador = identificador;
    }

    public Inmueble getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(Inmueble descripcion) {
        this.descripcion = descripcion;
    }

    public Direccion getDireccionLocal_t() {
        return direccionLocal_t;
    }

    public void setDireccionLocal_t(Direccion direccionLocal_t) {
        this.direccionLocal_t = direccionLocal_t;
    }

    public float getImporteAlquiler() {
        return importeAlquiler;
    }

    public void setImporteAlquiler(float importeAlquiler) {
        this.importeAlquiler = importeAlquiler;
    }

    
    
}