package clases;

/**
 *
 * @author Paula
 */
public class Direccion {
    
    String calle;
    String ciudad;
    String codPostal;

    public Direccion() {
    }

    public Direccion(String calle, String ciudad, String codPostal) {
        this.calle = calle;
        this.ciudad = ciudad;
        this.codPostal = codPostal;
    }

    public String getCalle() {
        return calle;
    }

    public void setCalle(String calle) {
        this.calle = calle;
    }

    public String getCiudad() {
        return ciudad;
    }

    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }

    public String getCodPostal() {
        return codPostal;
    }

    public void setCodPostal(String codPostal) {
        this.codPostal = codPostal;
    }

    
    
}
